<?php
try {
	
	// configuration
	$access = " Add License Key Here";
	$userid = " Add User Id Here";
	$passwd = " Add Password Here";
	
	$endpointurl = "  Add URL Here";
	$outputFileName = "XOLTResult.xml";
	
	// create a simple xml object for AccessRequest & QVRequest
	$accessRequesttXML = new SimpleXMLElement ( "<AccessRequest></AccessRequest>" );
	$qvRequestXML = new SimpleXMLElement ( "<QuantumViewRequest></QuantumViewRequest>" );
	
	// create AccessRequest XML
	$accessRequesttXML->addChild ( "AccessLicenseNumber", $access );
	$accessRequesttXML->addChild ( "UserId", $userid );
	$accessRequesttXML->addChild ( "Password", $passwd );
	
	// create QVRequest XML
	$request = $qvRequestXML->addChild ( 'Request' );
	$request->addChild ( "RequestAction", "QVEvents" );
	
	$requestXML = $accessRequesttXML->asXML () . $qvRequestXML->asXML ();
	
	// create Post request
	$form = array (
			'http' => array (
					'method' => 'POST',
					'header' => 'Content-type: application/x-www-form-urlencoded',
					'content' => "$requestXML" 
			) 
	);
	
	$request = stream_context_create ( $form );
	$browser = fopen ( $endpointurl, 'rb', false, $request );
	if (! $browser) {
		throw new Exception ( "Connection failed." );
	}
	
	// get response
	$response = stream_get_contents ( $browser );
	fclose ( $browser );
	
	if ($response == false) {
		throw new Exception ( "Bad data." );
	} else {
		// save request and response to file
		$fw = fopen ( $outputFileName, 'w' );
		fwrite ( $fw, "Request: \n" . $requestXML . "\n" );
		fwrite ( $fw, "Response: \n" . $response . "\n" );
		fclose ( $fw );
		
		// get response status
		$resp = new SimpleXMLElement ( $response );
		echo $resp->Response->ResponseStatusDescription . "\n";
	}
} catch ( Exception $ex ) {
	echo $ex;
}
?>